<?php
//akan tampil invoice, tempat kirim bukti bayar arahan ke wa untuk konfirmasi, tambahan note untuk pengingat
//ingin menampilkan tambahan alamat untuk pengiriman, norek pembayaran, dan tempat menginput bukti tf
session_start();
require '../login/tes.php';

if (isset($_POST['konfirmasi'])) {
    $id_pelanggan = $_SESSION['id_username'];
    $tanggal_pesanan = date('Y-m-d H:i:s');

    $queryTransaksi = mysqli_query($con, "INSERT INTO pesanan (id_username, waktu_pesanan, status_pesanan)
    VALUES ('$id_username', '$waktu_pesanan','$status_pesanan')");

    $queryPengiriman = mysqli_query($con, "INSERT INTO pesanan (id_username, tanggal_pesanan, alamat
    VALUES ($id_username, $tanggal_pesanan, $alamat ) ");

    unset($_SESSION['keranjang']); //untuk menghapus keranjang setelah transaksi
}

function generateRandomString($length = 10) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $charactersLength = strlen($characters);
    $randomString = "";
    for ($i = 0; $i < $length; $i++){
        $randomString .= $characters[rand(0, $charactersLength -1)] ;
    }
    return $randomString;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis  |  CheckOut</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php require 'navbar.php'; ?>

<div class="card box">
    <div class="card-body text-center">
        <h2 >Keranjang</h2>
    </div>
</div>

<div class="container">
<div class="card">
    <div class="card-body">
    
        <table class="table table-hover table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
$totalHarga = 0;

// Loop untuk menampilkan produk dalam keranjang
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    // Query data produk dari database
    $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE id_produk='$id_produk'");
    $produk = mysqli_fetch_assoc($queryProduk);

    // Hitung subtotal
    $harga = $produk['harga'];
    $subtotal = $harga * $jumlah;
    $totalHarga += $subtotal;
    ?>
    
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td>
                        <img src="../image/<?php echo $produk['foto']; ?>" alt="<?php echo $produk['nama_produk']; ?>" width="50">
                    </td>
                    <td><?php echo $produk['nama_produk']; ?></td>
                    <td><?php echo $jumlah; ?></td>
                    <td>Rp <?php echo number_format($harga, 0, ',', '.'); ?></td>
                    <td>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>

                    
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="5" class="text-end"><strong>Total</strong></td>
                    <td colspan="2"><strong>Rp <?php echo number_format($totalHarga, 0, ',', '.'); ?></strong></td>
                </tr>
            </tbody>
            </table>
            </div>
            </div>


<div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3 mt-4">
        
    </div>

    <h5 class="text-center"> Silahkan Lakukan pembayaran via Transfer ke nomer rekening berikut</h5>
    <h4 class=" justify text-center text-white" style="background-color: #C55C66"> BCA(Diah Ayu Prahastuti) 4350563976</h4>

<div class="may-5 col-12 col-md-6 col-md-8 offset-md-2 col-lg-6 offset-lg-3">
<div class="container mt-5">
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    
                </li>
            </ol>
        </nav> -->
        <form action="" method="post" enctype="multipart/form-data">
          <div class="input-group mb-3">
              <input type="text" class="form-control" placeholder="Ketikkan Alamat Kamu Disini, Ya!"  name="alamat" aria-describedby="button-uddon2">
          </div>
          <div>
            <label for="foto">Foto</label>
            <input type="file" name="foto" id="foto" class="form-control">
          </div>
        <div>
            <button type="submit" class="btn btn-primary col-md-8 offset-md-2 col-lg-6 offset-lg-3 mt-4" style="background-color: #C55C66"
            name="simpan">Simpan</button>
            

        </div>
      </form>
    <?php
        if (isset($_POST['simpan'])) {
            $alamat = htmlspecialchars($_POST['alamat']);
            $id_pelanggan = $_SESSION['id_pelanggan'];
            $target_dir = '../imagepayment/';
            $nama_file = basename($_FILES['foto']['name']);
            $target_file = $target_dir . $nama_file;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $image_size = $_FILES['foto']['size'];
            $random_name = generateRandomString(20);
            $new_name = $random_name . '.' . $imageFileType;

            foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
                // Query data produk dari database
                $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE id_produk='$id_produk'");
                $produk = mysqli_fetch_assoc($queryProduk);

                // Hitung subtotal
                $harga = $produk['harga'];
                $subtotal = $harga * $jumlah;

                $waktu_pesanan = date('Y-m-d H:i:s');
                $status_pesanan = 'Sedang Diproses';

                mysqli_query($con, "INSERT INTO pesanan (id_pelanggan, waktu_pesanan, status_pesanan, alamat, id_produk, kuantitas, subtotal) VALUES ('$id_pelanggan', '$waktu_pesanan', '$status_pesanan', '$alamat', '$id_produk', '$jumlah', '$subtotal')");
            }

        
                if ($nama_file != '') {
                    if ($image_size > 500000) {
                        ?>
                        <div class="alert alert-danger" role="alert">
                            File tidak boleh lebih dari 100 KB
                        </div>
                        <?php
                    } else {
                        if ($imageFileType != 'jpg' && $imageFileType != 'jpeg' && $imageFileType != 'png' && $imageFileType != 'gif') {
                            ?>
                            <div class="alert alert-danger" role="alert">
                                File wajib bertipe jpg, png, atau gif
                            </div>
                            <?php
                        } else {
                            move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $new_name);
                        }
                    }
                }
                echo "<script>location.href = 'done.php'</script>";
            }
?>
</div>
</div>

    
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../fontawesome/js/all.min.js"></script>
</body>
</html>