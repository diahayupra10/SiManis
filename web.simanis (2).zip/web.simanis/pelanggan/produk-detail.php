<?php
require "../login/tes.php";

// Tangkap parameter produk berdasarkan nama_produk
$nama_produk = htmlspecialchars($_GET["nama_produk"]);
$queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE nama_produk='$nama_produk'");
$produk = mysqli_fetch_assoc($queryProduk);

// Inisialisasi session
session_start();

// Tangani penambahan ke keranjang
if (isset($_POST['tambah_keranjang'])) {
    $id_produk = $_POST['id_produk'];

    // Jika keranjang belum ada, inisialisasi sebagai array kosong
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = [];
    }

    // Tambahkan produk ke keranjang atau tambahkan jumlah jika sudah ada
    if (isset($_SESSION['keranjang'][$id_produk])) {
        $_SESSION['keranjang'][$id_produk]++;
    } else {
        $_SESSION['keranjang'][$id_produk] = 1;
    }

    // Redirect untuk menghindari form resubmission
    header("Location: keranjang.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis | Detail Produk</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php require "navbar.php"; ?>  

<div class="container-fluid py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <img src="../image/<?php echo $produk['foto']; ?>" class="w-100" alt="">
            </div>
            <div class="col-md-6 offset-md-1">
                <h1><?php echo $produk['nama_produk']; ?></h1>
                <p class="text-harga">
                    Rp. <?php echo number_format($produk['harga'], 0, ',', '.'); ?>
                </p>
                <p class="fs-4 mt-3"> 
                    <?php echo $produk['deskripsi_produk']; ?>
                </p>
                
                <!-- Tambahkan form untuk Masukkan Keranjang -->
                <form method="POST">
                    <input type="hidden" name="id_produk" value="<?php echo $produk['id_produk']; ?>">
                    <button type="submit" name="tambah_keranjang" class="btn text-white mt-5" style="background-color: #CE6E75;">
                        Masukkan Keranjang
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require "footer.php"; ?>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../fontawesome/js/all.min.js"></script>
</body>
</html>