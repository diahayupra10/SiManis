<?php

session_start();
require "../login/tes.php";

// Periksa apakah keranjang sudah diinisialisasi
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    echo "<p>Keranjang kosong. Silakan tambahkan produk terlebih dahulu.</p>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis | Keranjang</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php require "navbar.php"; ?>

<div class="card box">
    <div class="card-body text-center">
        <h2 >Keranjang</h2>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <table class="table table-hover table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Subtotal</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $totalHarga = 0;

                // Loop untuk menampilkan produk dalam keranjang
                foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
                    // Query data produk dari database
                    $queryProduk = mysqli_query($con, "SELECT * FROM produk WHERE id_produk='$id_produk'");
                    $produk = mysqli_fetch_assoc($queryProduk);

                    // Hitung subtotal
                    $harga = $produk['harga'];
                    $subtotal = $harga * $jumlah;
                    $totalHarga += $subtotal;
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td>
                        <img src="../image/<?php echo $produk['foto']; ?>" alt="<?php echo $produk['nama_produk']; ?>" width="50">
                    </td>
                    <td><?php echo $produk['nama_produk']; ?></td>
                    <td><?php echo $jumlah; ?></td>
                    <td>Rp <?php echo number_format($harga, 0, ',', '.'); ?></td>
                    <td>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                    <td>
                        <a href="hapus_keranjang.php?id_produk=<?php echo $id_produk; ?>" class="btn btn-danger btn-sm">
                            Hapus
                        </a>
                    </td>
                    
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="5" class="text-end"><strong>Total</strong></td>
                    <td colspan="2"><strong>Rp <?php echo number_format($totalHarga, 0, ',', '.'); ?></strong></td>
                </tr>
                
            </tbody>
        </table>
        <div>
            <a href="checkout.php"class="btn text-white" style= "background-color: #CE6E75; " >Check This Out!</a>
            <a href="produk.php"class="btn text-white ms-3 " style= "background-color: #CE6E75; " >Kembali Ke Produk</a>
            </div>
        
    </div>
</div>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../fontawesome/js/all.min.js"></script>
</body>
</html>