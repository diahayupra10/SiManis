<?php
session_start();
require "../login/tes.php";

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content= "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <tittle></tittle>
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
</head>

<style>
    .main{
        height: 100 vh;

    }

    .login-box{
        width: 400px;
        height: 250px;
        box-sizing: border-box;
        border-radius: 15px;
        background-color: #FFB6C1;
    }


</style>

<body>
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
   <div class="main login-box flex-column mx-auto  align-items-center">
    <div class="login-box p-4 shadow">
    <form action=""method="POST">
            <div>
                <label for="username">Username</label>
                <input type="text"class="form-control" name="username" id="username">
            </div>
            <div>
                <label for="password">Password</label>
                <input type="password"class="form-control" name="password" id="password">
            </div>
            <br />
            <div>
                <button class="btn btn-success form-control" type="submit" style ="background-color: #C55C66" name="loginbtn">Login</button>
                
            </div>
        </form>
    </div>
   </div>
  
     <div class="mt-3" style="text-align:center">
        <?php
        if(isset($_POST["loginbtn"])){
            $username = htmlspecialchars ($_POST["username"]);
            $password = htmlspecialchars ($_POST["password"]);

            $query = mysqli_query($con, "SELECT * FROM pelanggan WHERE username= '$username' ");
            $countdata = mysqli_num_rows($query);
            $data = mysqli_fetch_array($query);
        
            
            if($countdata > 0){
                if($password== $data["password"]){
                    $_SESSION["username"] = $data["username"];
                    $_SESSION ["id_pelanggan"] = $data["id_pelanggan"];
                    $_SESSION["Login"] = true;
                    header("location: index.php");
                }
                else{
                    ?>
            <div class="alert alert-danger" role="alert">
                Password salah!
            </div>
            <?php
                }
            }
                 else{
            ?>
            <div class="alert alert-danger" role="alert">
                Akun Tidak Ditemukan!
            </div>
            <?php

        }
        }
           
            ?>
     </div>  
    
</body>
</html>