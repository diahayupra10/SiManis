<?php
session_start();
require "../login/tes.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis  | Terima Kasih</title>
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
</head>
<style>
    .main{
        height: 100 vh;

    }

    .login-box{
        width: 450px;
        height: 300px;
        box-sizing: border-box;
        border-radius: 15px;
        background-color: #CE6E75;
    }
    
</style>

<?php
// Path gambar background

?>
    
    <br />
    <br />
    <br />
    <br />
    <br />
    <br />
   <div class="main login-box flex-column mx-auto  align-items-center">
    <div class="login-box p-4 shadow">
        <h2 class="text-center text-white">Terima Kasih</h2>
        <h6 class="text-center text-white mt-3">Silahkan konfirmasi kembali pesanan anda via WhatsApp guna menghindari kekeliruan.</h6>
        <h6 class="text-center text-white">Terima kasih telah berbelanja!</h6>
        <h3 class="text-center text-white">Have A Nice Day, Manis!</h3>

        <div class="row justify-content-center">
        <div class="col-sm-1 d-flex justify-content-center mb-2 mt-4">
            <a href="https://wa.me/6285184611526" style="color: #ffffff;"><i class="fa-brands fa-whatsapp fs-3"></i></a>
        
        
    
        </div>
        <a href="produk.php"class="btn text-white mt-5 " style= "background-color: #CE6E75; " >Kembali Ke Produk</a>
        </div>
    </div>
</div>

    </div>
    </div>
        <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>