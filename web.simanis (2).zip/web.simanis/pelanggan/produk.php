<?php
require "../login/tes.php";

//get produk by nama produk keyword
if(isset($_GET["keyword"])){
    $queryProduk = mysqli_query($con,"SELECT * FROM produk WHERE nama_produk LIKE '%$_GET[keyword]%'");
}

//get produk by defult
else{
   $queryProduk = mysqli_query($con,"SELECT * FROM produk");
}

$countdata = mysqli_num_rows($queryProduk);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis | Produk</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php require "navbar.php"; ?>

<div class="container-fluid banner-produk d-flex align-items-center">
    <div class="container">
        
    <h1 class="text-center py-5 text-white">⋆⭒˚｡⋆ Produk</h1>
    </div>
</div>

<div class="row mt-5">
        <?php
    if($countdata<1){
        ?>
            <h4 class="text-center">Produk yang dicari tidak tersedia.</h4>
        <?php
    }
        ?>
        <?php while ($produk = mysqli_fetch_array($queryProduk)){?>
        <div class="col-md-3 mb-4">
        <div class="card">
        <div class="image-box">
        <img src="../image/<?php echo $produk['foto']; ?>" class="card-img-top" alt="...">
        </div>
        <div class="card-body">
            <h5 class="card-title"><?php echo $produk['nama_produk']; ?></h5>
            <p class="card-text text-truncate"><?php echo $produk['deskripsi_produk']; ?></p>
            <p class="card-text text-harga"> Rp. <?php echo $produk['harga']; ?></p>
            
            <a href="produk-detail.php?nama_produk=<?php echo $produk['nama_produk']; ?> 
            "class="btn text-white" style="background-color: #CE6E75; " >Lihat Disini!</a>
        </div>
        </div>
        </div>
        <?php } ?>
    
    </div>

<div class="container py-5">
    <div class="row">

    </div>
</div>

<?php require "footer.php"; ?>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../fontawesome/js/all.min.js"></script>
</body>
</html>