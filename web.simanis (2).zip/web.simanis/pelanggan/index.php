<?php
 require "../login/tes.php";
 $queryProduk = mysqli_query($con,"SELECT id_produk, nama_produk, harga, foto, deskripsi_produk FROM produk LIMIT 6");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SiManis | Home</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
</head>
<body>
<?php require "navbar.php"; ?>

    <div class="container-fluid banner d-flex align-items-center">
        <div class="container text-center">
            <div class="col-8 mt-3 offset-2">
                <form method="get" action="produk.php">
                    <div class="input-group  mb-2">
                        <input type="text" class="form-control" placeholder="cari apa?" aria-label="recipient's username"
                        aria-describedby="bassic-addon2" name="keyword">
                        <button type="submit" class="btn btn-pimary" style="background-color: #CE6E75" text-white>Cari</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<div class="container-fluid py-5" style="background-color: #E09698;">
    <div class="container text-center text-white">
    <h3>⋆⭒˚｡⋆ About Us</h3>
    <p class="fs-5 mt-4">
    Selamat datang di SiManis, tempat di mana cita rasa manis bertemu dengan kelezatan yang tak terlupakan! <br> Kami adalah toko dessert yang didedikasikan untuk 
    menyajikan berbagai pilihan hidangan penutup yang menggugah selera untuk memberikan kebahagiaan disetiap gigitannya.
    
    Apakah Anda sedang mencari dessert untuk membuat hari anda lebih Legit? SiManis siap untuk menemani setiap momen manis Anda.
    
    <br> Terima kasih telah memilih SiManis. Kami berkomitmen untuk terus menyajikan kenikmatan manis yang akan membuat hari Anda semakin berwarna!
    </p>
    </div>
</div>
<div class="container-fluid py-5">
    <div class="container text-center">
        <h3>⋆⭒˚｡⋆ Produk</h3>

        <div class="row mt-5">
            <?php while ($data = mysqli_fetch_array($queryProduk)) { ?>
        <div class="col-md-4 mb-3">
            <div class="card">
        <div class="image-box">
        <img src="../image/<?php echo $data['foto']; ?>" class="card-img-top" alt="...">
        </div>
        <div class="card-body">
            <h5 class="card-title"><?php echo $data['nama_produk']; ?></h5>
            <p class="card-text text-truncate"><?php echo $data['deskripsi_produk']; ?></p>
            <p class="card-text text-harga"> Rp.<?php echo $data['harga']; ?> </p>
            <a href="produk-detail.php?nama_produk=<?php echo $data['nama_produk']; ?>"class="btn text-white" style="background-color: #CE6E75;" >Lihat Disini!</a>
        </div>
        </div>
        </div>
          <?php } ?>
        </div>
        <a class="btn-btn-outline-primary text-white mt-3 py-2 fs-5" 
        style="border: #ffffff; border-radius: 5px; background-color: #CE6E75; text-decoration: none;" href="produk.php" >See More </a>
        </div>
    </div>
</div>
<?php require "footer.php"; ?>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../fontawesome/js/all.min.js"></script>
</body>
</html>