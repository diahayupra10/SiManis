<div class="container-fluid py-5 content-subscribe text-light" style="background-color: #CE6E75;">
    <div class="container">
        <h5 class="text-center mb-4">Find Us</h5>
        <div class="row justify-content-center">
        <div class="col-sm-1 d-flex justify-content-center mb-2">
            <i class="fa-brands fa-instagram fs-3"></i>
        </div>
        <div class="col-sm-1 d-flex justify-content-center mb-2">
            <a href="https://wa.me/6285184611526" style="color: #ffffff;"><i class="fa-brands fa-whatsapp fs-3"></i></a>
        </div>
        </div>
    </div>
    <h5 class="text-center mt-5 mb-5 text-white">Kode Unik Untuk Manis</h5>
    <p class="text-center font-monospace text-white">Ketikkan Kode Unik Untuk Dapatkan Promo</p>
    <div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Ketikkan Kode" 
            aria-label="Recipient's name" aria-describedby="button-uddon2">
            <button class="btn btn-warning text-align text-white  " type="button" id="button-addon2" style="background-color: #E09698;">Disini</button>
            
        </div>
    </div>
</div>