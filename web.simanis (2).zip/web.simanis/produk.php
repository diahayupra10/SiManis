<?php
require "session.php";
require "login/tes.php";


$queryProduk = mysqli_query($con, "SELECT * FROM produk");
$jumlahProduk = mysqli_num_rows($queryProduk);

function generateRandomString($length = 10) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $charactersLength = strlen($characters);
    $randomString = "";
    for ($i = 0; $i < $length; $i++){
        $randomString .= $characters[rand(0, $charactersLength -1)] ;
    }
    return $randomString;
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=P, initial-scale=1.0">
    <title>Produk</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/fontawesome.min.css">
</head>

<style>
    .no-decoration {
        text-decoration: none;
    }

    form div {
        margin-bottom: 10px;

    }
</style>

<body>
    <?php require "login/navbar.php" ?>

    <div class="container mt-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="../web.simanis" class="no-decoration text muted">
                        <i class="breadcrumb-item active" aria-current="page">
                            Produk
                        </i>
                    </a>
                </li>
            </ol>
        </nav>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="may-5 col-12 col-md-6">
                <h3>Tambah Produk</h3>

                <div>
                    <label for="nama_produk">Nama</label>
                    <input type="text" id="nama" name="nama" class="form-control" autocomplete="off" required>
                </div>
            </div>
            <div>
                <label for="harga">Harga</label>
                <input type="number" class="form-control" name="harga" required>
            </div>
            <div>
                <label for="foto">Foto</label>
                <input type="file" name="foto" id="foto" class="form-control">
            </div>
            <div>
                <label for="deskripsi_produk">Deskripsi Produk</label>
                <textarea name="deskripsi_produk" id="deskripsi_produk" cols="30" rows="10" class="form-control"
                    required></textarea>
            </div>
            <div>
                <button type="submit" class="btn btn-primary" style="background-color: #C55C66"
                    name="simpan">Simpan</button>
            </div>
        </form>

        <?php
        if (isset($_POST["simpan"])) {
            $nama_produk = htmlspecialchars($_POST["nama"]);
            $harga = htmlspecialchars($_POST["harga"]);
            $deskripsi_produk = htmlspecialchars($_POST["deskripsi_produk"]);

            $target_dir = "image/";
            $nama_file = basename($_FILES["foto"]["name"]);
            $target_file = $target_dir . $nama_file;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $image_size = $_FILES["foto"]["size"];
            $random_name = generateRandomString(20);
            $new_name = $random_name .".". $imageFileType;

            if ($nama_produk == "" || $harga == "" || $deskripsi_produk == "") {
                ?>
                <div class="alert alert-danger" role="alert">
                    Nama, harga dan deskripsi produk wajib ada!
                </div>
                <?php
            } else {
                if ($nama_file != "") {
                    if ($image_size > 500000) {
                        ?>
                        <div class="alert alert-danger" role="alert">
                            File tidak boleh lebih dari 500 KB
                        </div>
                        <?php
                    } else {
                        if ($imageFileType != 'jpg' && $imageFileType != 'jpeg' && $imageFileType != 'png' && $imageFileType != 'gif') {
                            ?>
                            <div class="alert alert-danger" role="alert">
                                File wajib bertipe jpg, png, atau gif
                            </div>
                            <?php
                        } else {
                            move_uploaded_file($_FILES["foto"]["tmp_name"], $target_dir . $new_name);
                        }
                    }
                }

              $queryTambah = mysqli_query($con, "INSERT INTO produk(nama_produk, harga, foto, deskripsi_produk) 
              VALUES ('$nama_produk', '$harga', '$new_name', '$deskripsi_produk' )");

              if ($queryTambah){
?>
                <div class="alert alert-primary mt-3" role="alert">
                    Produk Berhasil Tersimpan
                </div>

                <meta http-equiv="refresh" content="2; url=produk.php>
<?php
              }
              else{
                echo "mysqli_error($con)";
              }
            }
        }
        ?>
    </div>
    <div class="mt-3 mb-5">
        <h3>List Produk</h3>

        <class= table-responsive mt-5>
            <table class="table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($jumlahProduk == 0) {
                        ?>
                        <tr>
                            <td cosplan=4 class="text-center">Data Produk Tidak Tersedia</td>
                        </tr>
                        <?php
                    } else {
                        $jumlahProduk = 1;
                        while ($row = mysqli_fetch_array($queryProduk)) {
                            ?>
                            <tr>
                                <td><?php echo $jumlahProduk; ?></td>
                                <td><?php echo $row['nama_produk']; ?></td>
                                <td><?php echo $row['harga']; ?></td>
                                <td>
                                <a href="produk-detail.php?p=<?php echo $row['id_produk']; ?>" class="btn btn-info">
                                <i class="fas fa-search"></i></a>
                                
                                </td>
                            </tr>
                            <?php
                            $jumlahProduk++;
                        }

                    }
                    ?>
                </tbody>
            </table>
    </div>
    </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>

</html>