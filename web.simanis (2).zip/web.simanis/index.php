<?php
    require "session.php";
    require "login/tes.php";

    $queryProduk = mysqli_query($con,"SELECT * FROM produk");   
    $jumlahProduk = mysqli_num_rows($queryProduk);

    $queryStatus = mysqli_query($con,"SELECT * FROM pesanan");   
    $jumlahStatus = mysqli_num_rows($queryStatus);
                               
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome/css/fontawesome.min.css">
</head>

<style>
    .kotak{
        border: solid;

    }

    .summary-produk{
        background-color: #E9ABAC;
        border-radius: 10px;
    }
    .summary-status{
        background-color: #E9ABAC;
        border-radius: 10px;
        
    }

    .no-decoration{
        text-decoration: none ;
    }
</style>

<body>
    <?php require "login/navbar.php"?>
    <div class="container mt-5">
    <nav aria-label="breadcrumb">
     <ol class="breadcrumb">
    <li class="breadcrumb-item active" aria-current="page">
        <i class="fas fa-house"></i> Home
    </li>
    </ol>
    </nav>
        <h2>Halo <?php echo $_SESSION['username'];?></h2>

        <div class="container mt-5">
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <div class="summary-produk">
                    <div class="row">
                        <div class="col-7 px-4 text-white">
                            <h3>Produk</h3>
                            <p><?php echo $jumlahProduk; ?> produk</p>
                            <p><a href="produk.php" class="text-white no-decoration">Lihat Disini!</a></p>
                        </div>
                    </div>
                </div>
                </div>
                <div class="col-lg-4 mb-3">
                    <div class="summary-status">
                    <div class="row">
                        <div class="col-7 px-4 text-white">
                            <h3>Status</h3>
                            <p><?php echo $jumlahStatus; ?> Status</p>
                            <p><a href="status.php" class="text-white no-decoration">Lihat Disini!</a></p>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="fontawesome/js/all.min.js"></script>
</body>
</html>