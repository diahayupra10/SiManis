<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "toko_simanis";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi){
    die("gagal terkoneksi");
}else {
    echo "koneksi berhasil";
}